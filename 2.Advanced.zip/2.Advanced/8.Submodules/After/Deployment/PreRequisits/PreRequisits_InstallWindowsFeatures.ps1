﻿function CheckFeatureInstalled($FeatureLocal, $LogPathLocal)
{	
	$installedFeatures = Get-WindowsFeature -LogPath $LogPathLocal | Where-Object {$_.Installed -match "True"}
	$featureInstalled = $installedFeatures | Where-Object {$_.name -eq $FeatureLocal}
	return $featureInstalled
}

function InstallWindowsFeatures($windowsDistribLocal, $LogPathLocal,$windowsFeatureListPath)
{
	LogImportant "Call InstallWindowsFeatures"

	# Loading Feature Installation Modules
	Log ("Import-Module ServerManager")
	Import-Module ServerManager -ErrorAction Stop
		
	#для установки фич нужно явным образом указать от куда взять эти фичи. Можно из интернета, но ни кто не обещает что инет будет.
	#следовательно надо указать привод, где лежит образ.  А значит этот образ должен быть подмонтирован.
	Log ("Install-WindowsFeatures")
	
	#получаем все фичи, доступные в текущей редакции сервиса
	$allWindowsFeatures = Get-WindowsFeature -LogPath $LogPathLocal
	$allInstalledWindowsFeature = $allWindowsFeatures | Where-Object {$_.Installed -match "True"}
	
	#список фич, которые мы хотим установить
	$FeatureList = GetFeaturesFromFile $windowsFeatureListPath
	
	$FeatureListNotInstalled = GetNotInstalledFeatures $allInstalledWindowsFeature $FeatureList
	
	foreach ($Feature in $FeatureListNotInstalled) 
	{ 
		try 
		{
			#проверяем правильно ли мы написали название фичи, или поддерживает ли эта редакция сервера нашу фичу
			$featureNameCorrect = $allWindowsFeatures | Where-Object {$_.name -eq $Feature}
			if($featureNameCorrect -eq $null)
			{
				LogError ("featureName: "+$Feature + " unknown")
				Exit
			}
			else
			{
				#получаем список установленных фичей. Для каждой фичи берем заново, тк фичи могут быть зависимыми друг от друга и фича могли быть уже установлена. 				
				$featureInstalled = CheckFeatureInstalled $Feature $LogPathLocal
				
				if($featureInstalled -eq $null)
				{
					Log ("Installing-WindowsFeature: " + $Feature)
					Log ("Install-WindowsFeature -Name $Feature -Source $windowsDistribLocal -LogPath $LogPathLocal")
					Install-WindowsFeature -Name $Feature -Source $windowsDistribLocal -LogPath $LogPathLocal
					#Install-WindowsFeature -Name $Feature -IncludeAllSubFeature -Source $windowsDistribLocal -LogPath $LogPathLocal
					$afterInstallationCheck = CheckFeatureInstalled $Feature $LogPathLocal
					if($afterInstallationCheck -eq $null)
					{
						LogError ("Feature: $Feature installation failed")
						ExitCorrect
					}
				}
				else
				{
					#сюда мы можем попасть, если одна фича тянет за собой другую
					Log ("WindowsFeature: " + $Feature+ " already installed")
				}
			}
		}
		catch 
		{
			LogError $_
			LogError ("WindowsFeature: $Feature")
			ExitCorrect
		}
	} 
	
	#WMSVC Enable Remote Management
	Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WebManagement\Server -Name EnableRemoteManagement -Value 1 -ErrorAction Stop
	#WMSVC start Automatic
	Set-Service -name WMSVC -StartupType Automatic -ErrorAction Stop
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUtDBlaUUSkzEYYZNTQjgchrJV
# 1uigggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFKc2JDyXVX/5ynjhqjvz0f19K1pnMA0GCSqGSIb3DQEBAQUABIGAjxc3
# 6LbAxnM47VXdVmOkw9MXkVV5KA822Qnbzim2mDI/1JGX5fYy2rvu4wzU76+3CDeF
# lC2iwPSD89r/7zVoHIgHE9dsPNB0n2qpwBcg0Y2QfYLdcnw2HbjLuVM4c7aZAdAV
# 1JXr1yHAWHHdAREJVbvbfXcSvCY8lrdPgT0UJUg=
# SIG # End signature block
