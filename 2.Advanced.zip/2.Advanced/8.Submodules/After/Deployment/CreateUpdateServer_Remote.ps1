﻿param (
	$server, 
	$AppPoolName, 
	$AppPackagePath, 
	$AppPackageParamPath, 
	$RootWebSiteName, $RootWebSiteAppPoolName, $RootWebSiteAppPoolPassword, $RootWebSiteAppPoolLogin,
	$AppPoolOverridePolicy,
	$AppPoolPassword, $AppPoolLogin,
	$AppFolderPath,
	$AppServiceFolderName,
	$AppServiceVersion
)
$globalComputerName = $server
. .\Shared\Shared_Logs.ps1
. .\Shared\Shared_Validate.ps1
. .\CreateUpdateServer\Apps_Update.ps1
. .\CreateUpdateServer\Apps_Create.ps1
. .\CreateUpdateServer\AppPool.ps1

CheckOsServerOrClient $server
	
CheckIISInstaled $server

if($mode -eq "update")
{		
	UpdateApp $server $AppPoolName $AppPackagePath  $AppPackageParamPath		
}
else
{
	if($mode -eq "create")
	{
		CreateApp $server $RootWebSiteName $RootWebSiteAppPoolName $RootWebSiteAppPoolPassword $RootWebSiteAppPoolLogin $AppPoolOverridePolicy $AppPoolName $AppPoolPassword $AppPoolLogin $AppFolderPath $AppServiceFolderName $AppServiceVersion $AppPackagePath $AppPackageParamPath
	}
	else
	{
		LogError ("create or update mode?!")
		ExitCorrect
	}
}
# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU+XT4e5EMVZssy1UzpOKv61tJ
# EBagggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFMVE56mTvPo1pn9l+iMMxtlHRM2jMA0GCSqGSIb3DQEBAQUABIGAEjtS
# Em4fl1NpW4sVpMcX9OK+hhDtVOIVbSJIoUJvOU/fcID0oLr0YNwep3hHqwTUte6R
# 8y0AHIUx1B7VYrqDz0U4t+XITjH+hY30GDnyV6Antk6BUqXW3fiq6l9np3VL3UX2
# 58044+G3fiSINreCNCrmu5/viWFoLetZdffeXKM=
# SIG # End signature block
