﻿#скрипт нужен, для инициализации AppFabric отдельно от основного процесса.
function InitializeAppFabricDB
{
	LogImportant ("Call InitializeAppFabricDB")
	#$env:PSModulePath кэшируется во время старта сессии powershell. Из-за этого ApplicationServer не находится.
	Log "Import-Module ApplicationServer"
	
	$monitoringDBPermissions = ChechUserDBRights $MonitoringDatabaseServerNameLocal
	if($monitoringDBPermissions -eq $false)
	{
		#проблема в том, что при Initialize-ASMonitoringSqlDatabase создается не только база, но и job. А для этого уже нужны права на создание job
		#для Initialize-ASPersistenceSqlDatabase такой проблемы нет.
	
		#к примеру сейчас на test-sbpm-1 у меня есть права создать базу, но не удалить. Для этого нужны права Alter Any Database.
		#попытка удалить инстанс базы данных приводит к ошибке, если прочесть разширенный отчет, то приводит к ссылке
		#http://msdn.microsoft.com/en-us/library/ms813959.aspx если глянуть в список прав на уровне доменных политик, то оказывается что у моего пользователя нет этих прав.
		LogError ("Problems with DB Access: $MonitoringDatabaseNameLocal")
		LogError ("проблема в том, что при Initialize-ASMonitoringSqlDatabase создается не только база, но и job. А для этого уже нужны права уровня SA.")
		ExitCorrect
	}
	#$persistanceDBPermissions = ChechUserDBRights $PersistanceDatabaseNameLocal
	
	Log "Import-Module ApplicationServer"
	$appFabricInstallPath="C:\Program Files\AppFabric 1.1 for Windows Server\PowershellModules"
	CheckDependencyExists $appFabricInstallPath
	
	$Env:PSModulePath=$Env:PSModulePath+";"+$appFabricInstallPath
	Import-Module ApplicationServer -ErrorAction Stop
	
	Log "Init Monitoring Database"
	Log "MonitoringDatabaseName: $MonitoringDatabaseNameLocal"
	Log "MonitoringDatabaseServerName: $MonitoringDatabaseServerNameLocal"
	$initMonitoringDB = Initialize-ASMonitoringSqlDatabase -Database $MonitoringDatabaseNameLocal -Server $MonitoringDatabaseServerNameLocal  -Admins $MonitoringAdminsGroupName -Readers $MonitoringReadersGroupName –Writers $MonitoringWritersGroupName
	
	Log "Init Persistance Database"
	Log "PersistanceDatabaseName: $PersistanceDatabaseNameLocal"
	Log "PersistanceDatabaseServerName: $PersistanceDatabaseServerNameLocal"
	$initPersistenceDB = Initialize-ASPersistenceSqlDatabase -Database $PersistanceDatabaseNameLocal -Server $PersistanceDatabaseServerNameLocal -Admins $PersistenceAdminsGroupName -Readers $PersistenceReadersGroupName -Users $PersistenceUsersGroupName
	
	$applicationStrings=@{}
	$applicationStrings.Add($MonitoringConnectionNameLocal,$initMonitoringDB.ConnectionString)
	$applicationStrings.Add($PersistanceConnectionNameLocal,$initPersistenceDB.ConnectionString)
	return $applicationStrings
}
# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUVZ8B74h5QcZ0wIOmsWhcL3MQ
# kCCgggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFHDpUvj0pQNJRlerg/juK5SSMilHMA0GCSqGSIb3DQEBAQUABIGAKMcd
# aYsi4e8uu8MOoe0EROaKQV5Uodu/jgR2CEuxXBj7h94tAnftOPpP2lLFnCM3m8C/
# qgcQLVab7wXx1F2bS58WudaP9s9sClV+vaHLJVypDPgK6hoqiYyV2u5kdiYdJASc
# BbvoRMksWl0LpI5cOURxUD6V8qUFdt5STIDDpec=
# SIG # End signature block
