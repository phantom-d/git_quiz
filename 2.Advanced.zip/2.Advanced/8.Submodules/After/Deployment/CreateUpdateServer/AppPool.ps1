﻿function CreateAppPool($AppPoolName,$AppPoolUserPassword, $AppPoolUserName )
{
	LogImportant ("Call CreateAppPool")
	Log ("Creating application pool $AppPoolName")	
	
	$appPool= New-WebAppPool $AppPoolName
	if($appPool -eq $null)
	{
		LogError ("AppPool Creation problem")
		ExitCorrect
	}
	else
	{
		Log ("Created application pool "+$AppPoolName)
	}
	
	Log "Set .net runtime version to applicaion pool started."
	$poolPath = "IIS:\AppPools\" + $AppPoolName
	Set-ItemProperty $poolPath startMode AlwaysRunning -ErrorAction Stop
	Set-ItemProperty $poolPath managedRuntimeVersion v4.0 -ErrorAction Stop
	

	if($AppPoolUserName -eq $null)
	{
		LogError ("Param AppPoolUserName: Is null")
		ExitCorrect
	}
	if($AppPoolUserPassword -eq $null)
	{
		LogError ("Param AppPoolUserPassword: Is null")
		ExitCorrect
	}
	Set-ItemProperty $poolPath -name processModel -value  @{userName=$AppPoolUserName;password=$AppPoolUserPassword;identitytype=3}

	Log "Set .net runtime version to applicaion pool finished."
	
	Log ("Start-WebAppPool: $AppPoolName")
	Start-WebAppPool $AppPoolName
}

function CheckCreateAppPool($AppPoolOverridePolicy,$AppPoolName,$AppPoolUserName,$AppPoolUserPassword)
{
	LogImportant ("Call CheckCreateAppPool")
	Log ("AppPoolName: $AppPoolName")
	
	if($AppPoolName -eq $null)
	{
		LogError ("AppPoolName is null")
		ExitCorrect
	}
	
	$appPool = Get-ChildItem IIS:\apppools  | Where-Object {$_.name -eq $AppPoolName}
	#check if the app pool exists
	if ($appPool -ne $null)
	{
		if($AppPoolOverridePolicy -eq "use_exist")
		{
			IsAppPoolUsed $AppPoolName
		}
		if($AppPoolOverridePolicy -eq "exit")
		{
			LogError ("Application Pool $IISAppPoolName exists." )
			ExitCorrect
		}
	}
	else
	{
		Log ("Application pool $IISAppPoolName doesn't exist.")
		CreateAppPool $AppPoolName $AppPoolUserName $AppPoolUserPassword
	}
}

function IsAppPoolUsed($AppPoolName)
{
	LogImportant ("Call IsAppPoolUsed")
	#мы не имеем право использовать application pool, если его использует кто-либо. 
	
	$sites = Get-Website | Where-Object {$_.applicationPool -eq $AppPoolName}
	$applications = Get-WebApplication | Where-Object {$_.applicationPool -eq $AppPoolName}
	if(($sites -ne $null) -or($applications -ne $null))
	{
		LogError ("Application pool $AppPoolName Used by site")
		if($sites -ne $null)
		{
			foreach($site in $sites)
			{
				LogError ("	"+$site.name)
			}
		}
		if($applications -ne $null)
		{
			foreach($application in $applications)
			{
				LogError ("	"+$application.path)
			}
		}
		ExitCorrect
	}
}
# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUmgPj0mMbUtlOAHUwyqAJ+OX4
# s5agggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFKW35rZ0Nx2nNKcrIWaPUcqyfABsMA0GCSqGSIb3DQEBAQUABIGAekSL
# vqFPS1wsD53xyHW1CtV6gPrrDfFhMz1ekLs7vRASsUgVxgTveRj+QI3r3i8K1zFB
# ofuH4zC9DOFUv5rsDRXbMAl9ErFOs5C3WtvEdTPVvMkuL6NreAY6orBqmWs8I2OM
# xJzQP40mS3KwDeRfzm98Snw6QgMxulrk5Hz8QPQ=
# SIG # End signature block
