﻿function CreateNewDir ($path)
{
	LogImportant "Call CreateNewDir"
	$istempDirExist= Test-Path -Path $path -ErrorAction Stop
	if($istempDirExist -eq $false)
	{
		New-Item -ItemType directory -Path $path -ErrorAction Stop
	}
	else
	{	
		LogError("Folder exists: $path")
		ExitCorrect
	}
}

function CreateRootSiteIfNotExist($RootWebSiteName,$RootWebSiteAppPoolName,$SiteFoledPathLocal,$RootWebSiteAppPoolPassword,$RootWebSiteAppPoolLogin)
{
	LogImportant ("Call CreateRootSiteIfNotExist")
	#Log $RootWebSiteAppPoolPassword
	#Log $RootWebSiteAppPoolLogin
	# создаем основной сайт, который будет содержать приложения, если его не существует.
	Import-Module WebAdministration -ErrorAction Stop
	
	$defaultSiteName="Default Web Site"
	$isDefaultSiteExist = Get-Website | Where-Object {$_.name -eq $defaultSiteName}
	if($isDefaultSiteExist -ne $null)
	{
		LogImportant("Remove Default WebSite")
		Remove-WebSite -Name $defaultSiteName	
	}
	
	$isMainSiteExist = Get-Website | Where-Object {$_.name -eq $RootWebSiteName}
	if($isMainSiteExist -eq $null)
	{
		$appPool = Get-ChildItem IIS:\apppools  | Where-Object {$_.name -eq $AppPoolName}
		
		if($appPool -eq $null)
		{
			CreateAppPool $RootWebSiteAppPoolName $RootWebSiteAppPoolPassword $RootWebSiteAppPoolLogin
		}
		else
		{
			LogImportant("Site Apppool exists")
		}
		
		if($SiteFoledPathLocal -eq $null)
		{
			LogError("SiteFoledPathLocal is null")
			ExitCorrect
		}
		else
		{
			Log("SiteFoledPathLocal is $SiteFoledPathLocal")
		}
		
		CreateNewDir $SiteFoledPathLocal
		
		New-Website -ApplicationPool $RootWebSiteAppPoolName -Name $RootWebSiteName -Port 80 -PhysicalPath $SiteFoledPathLocal -ErrorAction Stop
		$isMainSiteExist = Get-Website | Where-Object {$_.name -eq $RootWebSiteName}
		
		#если сайт создать не удалось-то кричим что все пропало.
		if($isMainSiteExist -eq $null)
		{
			LogError "Main web site was not created"
			ExitCorrect
		}
		#естанавливаем bindings
		New-ItemProperty IIS:\sites\$RootWebSiteName -name bindings -value @{protocol="net.tcp";bindingInformation="909:*"} -ErrorAction Stop
		New-ItemProperty IIS:\sites\$RootWebSiteName -name bindings -value @{protocol="net.pipe";bindingInformation="*"} -ErrorAction Stop
		#устанавливаем enable protocols
		Set-ItemProperty IIS:\sites\$RootWebSiteName -name EnabledProtocols -Value "http,net.tcp,net.pipe" -ErrorAction Stop
	}
}

function CreateNewEmthyApp($RootWebSiteName,$NewAppPoolName,$NewAppFolderPathLocal,$NewAppServiceFolderNameLocal,$NewAppServiceVersionLocal)
{	
	LogImportant ("Call CreateNewApp")
	$folderPath = $NewAppFolderPathLocal + "\" + $NewAppServiceFolderNameLocal + "\"+ $NewAppServiceVersionLocal
	#если такая версия уже есть, то создать нельзя. Надо обновлять
	$folderPathExist= Test-Path $folderPath -ErrorAction Stop
	if($folderPathExist -eq $true)
	{
		LogError ("Folder exists" + $folderPath )
		ExitCorrect
	}

	#создаем приложение
	New-Item -ItemType directory -Path $folderPath -ErrorAction Stop
	$applicationName=($NewAppServiceFolderNameLocal + "\"+ $NewAppServiceVersionLocal)
	New-WebApplication -Name $applicationName -Site $RootWebSiteName -PhysicalPath $folderPath -ApplicationPool $NewAppPoolName 
	$sitePropName="IIS:\Sites\$RootWebSiteName\$applicationName"
	Set-ItemProperty $sitePropName enabledProtocols "http,net.tcp,net.pipe" 
	
	Import-Module ApplicationServer -ErrorAction Stop
	
	#при деплои по умолчанию берется из базы. Чтобы перетереть нужно вызвать эту команду
#	$applicationVirtualPath = $NewAppServiceFolderNameLocal+"/"+$NewAppServiceVersionLocal
#	Write-Host "Set-ASAppSqlServicePersistence –SiteName $RootWebSiteName –VirtualPath $applicationVirtualPath -UseInherited" 
#	Set-ASAppSqlServicePersistence –SiteName $RootWebSiteName –VirtualPath $applicationVirtualPath -UseInherited
}

function CreateApp(
$ComputerName,
$RootWebSiteName,
$RootWebSiteAppPoolName,
$RootWebSiteAppPoolPassword,
$RootWebSiteAppPoolLogin,
$AppPoolOverridePolicy, 
$NewAppPoolName,
$NewAppPoolPassword,
$NewAppPoolLogin,
$NewAppFolderPathLocal,
$NewAppServiceFolderNameLocal,
$NewAppServiceVersionLocal,
$CreateAppPackagePath,
$CreateAppPackageParamPath,
$PersistanceConnectionStringName
)
{
	LogImportant ("Call CreateApp")
	
	Import-Module WebAdministration -ErrorAction Stop
	
	CreateRootSiteIfNotExist $RootWebSiteName $RootWebSiteAppPoolName $NewAppFolderPathLocal $RootWebSiteAppPoolPassword $RootWebSiteAppPoolLogin
	
	CheckCreateAppPool $AppPoolOverridePolicy $NewAppPoolName $NewAppPoolPassword $NewAppPoolLogin 
	
	CreateNewEmthyApp $RootWebSiteName $NewAppPoolName $NewAppFolderPathLocal $NewAppServiceFolderNameLocal $NewAppServiceVersionLocal $PersistanceConnectionStringName

	UpdateApp $ComputerName $CreateAppPackagePath $CreateAppPackageParamPath $NewAppServiceFolderNameLocal $NewAppServiceVersionLocal $RootWebSiteName
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU45dZkxDC2+0tfxVQgUekpplw
# PpugggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFFB4Bbaf86VSdzkZpeRZQ1BUjiKoMA0GCSqGSIb3DQEBAQUABIGAUo4Y
# uzXZmG4b8G4LWTTEaTH3juAnf4Bqw1sRtn0p3SYzL41P6gOvy60GpANSWqq8rRCE
# +AEcjApFj/m33WoxU+9ZHUDNlbsZQc0PFEiDuKvpIecrYsD2OGcYFWwTALo+KVsH
# HGXOr/vztF8zjKuHmhoQryKmiDxxaNn0JaovIj8=
# SIG # End signature block
