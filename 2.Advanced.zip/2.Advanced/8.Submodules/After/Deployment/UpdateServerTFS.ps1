﻿param (
	$LocalFolder,
	$UpdateAppPackagePath, 
	$UpdateAppPackageParamPath, 
	$NewAppServiceFolderName, 
	$NewAppServiceVersion, 
	$RootWebSiteName,
	$serverListString
)

#$LocalFolder="\\sbpm-builder\BuildResults\DMS\DMS_CI_Dev_DevelopmentWithDeploy\2.3.5.0123.6\deploy"
#$UpdateAppPackagePath="\\sbpm-builder\BuildResults\DMS\DMS_CI_Dev_DevelopmentWithDeploy\2.3.5.0123.6/bin\_PublishedWebsites\Vtb24.Services.Dms.Web_Package\Vtb24.Services.Dms.Web.zip"
#$UpdateAppPackageParamPath="\\sbpm-builder\BuildResults\DMS\DMS_CI_Dev_DevelopmentWithDeploy\2.3.5.0123.6/bin\_PublishedWebsites\Vtb24.Services.Dms.Web_Package\Vtb24.Services.Dms.Web.SetParameters.xml"
#$NewAppServiceFolderName= "Vtb24.Services.Dms.Web"
#$NewAppServiceVersion="v20"
#$RootWebSiteName="Workflows"
#$serverListString="test-sbpm-1"

#Write-Host $LocalFolder -ForegroundColor Black -BackgroundColor Green
#Write-Host $UpdateAppPackagePath -ForegroundColor Black -BackgroundColor Green
#Write-Host $UpdateAppPackageParamPath -ForegroundColor Black -BackgroundColor Green
#Write-Host $NewAppServiceFolderName -ForegroundColor Black -BackgroundColor Green
#Write-Host $NewAppServiceVersion -ForegroundColor Black -BackgroundColor Green
#Write-Host $RootWebSiteName -ForegroundColor Black -BackgroundColor Green
#Write-Host $serverListString -ForegroundColor Black -BackgroundColor Green

$globalComputerName = $Env:COMPUTERNAME
$LogPathLocal = $LocalFolder+"\updatelog.txt"

$serverList1 = $serverListString.Split("XXX")
$serverList=@()
foreach ($server in $serverList1)
{
	if(($server -ne $null ) -and ($server -ne ""))
	{
		$serverList+=$server
		Write-Host ("	Server:"+$server)
	}
}

cd $LocalFolder
. .\Shared\Shared_Logs.ps1
. .\Shared\Shared_Validate.ps1
. .\CreateUpdateServer\Apps_Update.ps1

IsAdmin

foreach ($server in $serverList)
{
	$globalComputerName = $server
	Log ("Update Application on : "+$server)
	$session = New-PSSession -ComputerName $server -ErrorAction Stop
	
	UpdateApp $server $UpdateAppPackagePath $UpdateAppPackageParamPath $NewAppServiceFolderName $NewAppServiceVersion $RootWebSiteName $session
	
	Remove-PSSession -Session $session
} 
# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUH278cs5ZTiXR3JMIFcjgUIz0
# tEWgggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFOa8SkIe/WXHwBNBUoNAMfvpifZQMA0GCSqGSIb3DQEBAQUABIGAELkI
# 6cKTfGeaOpyfsan5ZTaFp8VHaqthheU0lC/a78IK4VkgRMZc+j3mcNtbLBhVFNsc
# h/ypa45yqKznSH4XG1a7E0P+VVb3Ca9NRobpWvlhWuUQF3z3briVazVRcVh/j1C7
# izSTMJnDafYaaP3arzbz981IfF9qwwkzbTKPz4c=
# SIG # End signature block
