﻿
function GetLogMessage($logEvent)
{
	$timeString = Get-Date -Format "H:mm:ss"
	$outString= ($timeString+"	"+$globalComputerName+"	"+ $logEvent)
	return $outString
}

function Log($logEvent)
{	
	$outString = GetLogMessage $logEvent
	Write-Host $outString -ForegroundColor Gray -ErrorAction Stop
	Out-File -ErrorAction Stop -Encoding Unicode -FilePath $LogPathLocal -inputobject $outString -Append 
}

function LogImportant($logEvent)
{	
	$outString = GetLogMessage $logEvent
	Write-Host $outString -ForegroundColor White -BackgroundColor Green -ErrorAction Stop
	Out-File -ErrorAction Stop -Encoding Unicode -FilePath $LogPathLocal -inputobject $outString -Append 
}

function LogError($logEvent)
{
	$outString = GetLogMessage $logEvent
	Write-Host $outString -ForegroundColor Red -BackgroundColor Black -ErrorAction Stop
	Out-File -ErrorAction Stop -Encoding Unicode -FilePath $LogPathLocal -inputobject $outString -Append  
}

function LogWarning($logEvent)
{
	$outString = GetLogMessage $logEvent
	Write-Host $outString -ForegroundColor Yellow -BackgroundColor Black -ErrorAction Stop
	Out-File -ErrorAction Stop -Encoding Unicode -FilePath $LogPathLocal -inputobject  $outString -Append 
}

# SIG # Begin signature block
# MIID2QYJKoZIhvcNAQcCoIIDyjCCA8YCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUXf8FrlZMlHGKHsA7LFl8aS0g
# 9c2gggIBMIIB/TCCAWqgAwIBAgIQOGz6cUwXY5VAVjOD1ZQlWDAJBgUrDgMCHQUA
# MA4xDDAKBgNVBAMTA1BXRDAeFw0xNDAxMjQxMDM5MjFaFw0zOTEyMzEyMzU5NTla
# MBoxGDAWBgNVBAMTD1Bvd2VyU2hlbGwgVXNlcjCBnzANBgkqhkiG9w0BAQEFAAOB
# jQAwgYkCgYEAkGJ05dKArthgrLTK9ZTVCWcHMofDthUwUugj4pDwbfD1yDJTbhXM
# +Uwen5EKb28AKhG3bhfzktGQ6pLGVtRchwK4MtyDfIYfFrH1OPHETn2MdOcb0Z2f
# WWIa22/kaSHkbnSl+m29jT3sR29JiVtzoDMbZf0wSdq32Fzg6pKZmPECAwEAAaNY
# MFYwEwYDVR0lBAwwCgYIKwYBBQUHAwMwPwYDVR0BBDgwNoAQwVETxPxOz6UW/9CI
# JydBlKEQMA4xDDAKBgNVBAMTA1BXRIIQS8pfBxjnqI1PhFWRqSMqyTAJBgUrDgMC
# HQUAA4GBAIMCfHB64TNIScJEJGhkNCum5UwOCh64+CUECV8gZfQiYhiUBNDWcy5c
# j+V9ayHnR1uhRsrk5K8pXZWIAtyEEhels+2dPgpRgX5ZOfaS8KgydqS98PPV6RgJ
# 2e6eLvEyNITEffDxSIbZZrt9ltYXYg1DGGKOLkDObLcObM+fHKuuMYIBQjCCAT4C
# AQEwIjAOMQwwCgYDVQQDEwNQV0QCEDhs+nFMF2OVQFYzg9WUJVgwCQYFKw4DAhoF
# AKB4MBgGCisGAQQBgjcCAQwxCjAIoAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisG
# AQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcN
# AQkEMRYEFMj4A0ilATAups7AIPuwMKZdo+7KMA0GCSqGSIb3DQEBAQUABIGAY6vX
# SYK4BRo+LX4G/7000iz+zsBu3wD1dHFbFzYWhNrWDH0PmEE2r6PyxdvlW6Qwc7ih
# TOmhnpzICUEpXOoCpH1KFwK2UAFTODA3QSMWtchiT1B6mbLGztMwI0RjthbXunQE
# VM/WvNhfXbf4IFenOOWOyeL5Fe5Q+AJHtTVLhQU=
# SIG # End signature block
